For video versions used in the user study:
	1. Static: Traditional fixed version where subtitles are always put at the bottom of the screen
	2. D1: our result
	3. D2: [Hong et al. 2010]'s result
	4. D3: Combine our speaker detection with [Hong et al. 2010]��s subtitle placement
	
For all the scores, the higher, the better.